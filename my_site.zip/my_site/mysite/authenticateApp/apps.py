from django.apps import AppConfig


class AuthenticateappConfig(AppConfig):
    name = 'authenticateApp'
